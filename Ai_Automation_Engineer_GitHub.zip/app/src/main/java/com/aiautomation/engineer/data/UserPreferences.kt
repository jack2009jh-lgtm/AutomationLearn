package com.aiautomation.engineer.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

val Context.dataStore by preferencesDataStore(name = "user_learning_state")

class UserPreferences(private val context: Context) {

    val readLessonsFlow: Flow<Set<String>> = context.dataStore.data.map { prefs ->
        prefs[stringSetPreferencesKey("read_lessons")] ?: emptySet()
    }

    suspend fun toggleLessonRead(lessonId: String, isRead: Boolean) {
        context.dataStore.edit { prefs ->
            val key = stringSetPreferencesKey("read_lessons")
            val current = prefs[key]?.toMutableSet() ?: mutableSetOf()
            if (isRead) current.add(lessonId) else current.remove(lessonId)
            prefs[key] = current
        }
    }

    suspend fun saveQuizScore(lessonId: String, score: Int) {
        context.dataStore.edit { prefs ->
            prefs[intPreferencesKey("score_$lessonId")] = score
        }
    }

    suspend fun saveProjectTier(lessonId: String, tierName: String) {
        context.dataStore.edit { prefs ->
            prefs[stringPreferencesKey("tier_$lessonId")] = tierName
        }
    }
}
