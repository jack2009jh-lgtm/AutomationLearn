package com.aiautomation.engineer.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LearningPathScreen(
    viewModel: MainViewModel,
    onLessonClick: (String) -> Unit
) {
    val course by viewModel.courseData.collectAsState()
    val readLessons by viewModel.readLessons.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(course?.stageName ?: "Ai automation engineer") }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            item {
                val totalLessons = course?.modules?.sumOf { it.lessons.size } ?: 0
                val completedCount = readLessons.size
                val progressFraction = if (totalLessons > 0) completedCount.toFloat() / totalLessons else 0f

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "وضعیت تسلط: $completedCount از $totalLessons درس تکمیل شده",
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        LinearProgressIndicator(
                            progress = { progressFraction },
                            modifier = Modifier.fillMaxWidth().height(8.dp),
                        )
                    }
                }
            }

            course?.modules?.forEach { module ->
                item {
                    Text(
                        text = "${module.moduleId}: ${module.title}",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(top = 12.dp, bottom = 6.dp)
                    )
                }

                items(module.lessons) { lesson ->
                    val isRead = readLessons.contains(lesson.lessonId)

                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .clickable { onLessonClick(lesson.lessonId) },
                        colors = CardDefaults.cardColors(
                            containerColor = if (isRead) Color(0xFFE8F5E9) else MaterialTheme.colorScheme.surfaceVariant
                        )
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "${lesson.lessonId} — ${lesson.title}",
                                    style = MaterialTheme.typography.bodyLarge
                                )
                                Text(
                                    text = "زمان آموزش: ${lesson.learningTimeMinutes} دقیقه | تمرین: ${lesson.practiceTimeMinutes} دقیقه",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color.Gray
                                )
                            }
                            Checkbox(
                                checked = isRead,
                                onCheckedChange = { checked ->
                                    viewModel.markLessonStatus(lesson.lessonId, checked)
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}
