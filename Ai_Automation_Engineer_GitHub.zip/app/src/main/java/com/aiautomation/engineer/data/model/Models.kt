package com.aiautomation.engineer.data.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class CourseData(
    val course: String,
    val stage: Int,
    @SerialName("stage_name") val stageName: String,
    val modules: List<ModuleData>,
    @SerialName("weekly_summaries") val weeklySummaries: List<WeeklySummaryData> = emptyList(),
    @SerialName("final_exam") val finalExam: FinalExamData? = null
)

@Serializable
data class ModuleData(
    @SerialName("module_id") val moduleId: String,
    val title: String,
    val lessons: List<LessonData>
)

@Serializable
data class LessonData(
    @SerialName("lesson_id") val lessonId: String,
    val title: String,
    @SerialName("learning_time_minutes") val learningTimeMinutes: Int = 15,
    @SerialName("practice_time_minutes") val practiceTimeMinutes: Int = 10,
    val prerequisites: List<String> = emptyList(),
    @SerialName("mastery_criteria") val masteryCriteria: String = "",
    @SerialName("practical_examples") val practicalExamples: List<String> = emptyList()
)

@Serializable
data class WeeklySummaryData(
    @SerialName("summary_id") val summaryId: String,
    val title: String,
    @SerialName("covered_lessons") val coveredLessons: List<String>,
    @SerialName("mastery_criteria") val masteryCriteria: String = ""
)

@Serializable
data class FinalExamData(
    @SerialName("exam_id") val examId: String,
    @SerialName("passing_score") val passingScore: Int = 85,
    val coverage: String,
    @SerialName("mastery_criteria") val masteryCriteria: String = ""
)
