package com.aiautomation.engineer

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.MaterialTheme
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.aiautomation.engineer.ui.LearningPathScreen
import com.aiautomation.engineer.ui.LessonDetailScreen
import com.aiautomation.engineer.ui.MainViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                val navController = rememberNavController()
                val viewModel: MainViewModel = viewModel()

                NavHost(navController = navController, startDestination = "learning_path") {
                    composable("learning_path") {
                        LearningPathScreen(
                            viewModel = viewModel,
                            onLessonClick = { lessonId ->
                                navController.navigate("lesson_detail/$lessonId")
                            }
                        )
                    }
                    composable("lesson_detail/{lessonId}") { backStackEntry ->
                        val lessonId = backStackEntry.arguments?.getString("lessonId") ?: ""
                        LessonDetailScreen(
                            lessonId = lessonId,
                            viewModel = viewModel,
                            onBack = { navController.popBackStack() }
                        )
                    }
                }
            }
        }
    }
}
