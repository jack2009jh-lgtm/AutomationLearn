package com.aiautomation.engineer.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LessonDetailScreen(
    lessonId: String,
    viewModel: MainViewModel,
    onBack: () -> Unit
) {
    val lesson = remember(lessonId) { viewModel.getLessonById(lessonId) }
    val readLessons by viewModel.readLessons.collectAsState()
    val isRead = readLessons.contains(lessonId)

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(lesson?.title ?: "جزئیات درس") },
                navigationIcon = {
                    TextButton(onClick = onBack) {
                        Text("بازگشت")
                    }
                }
            )
        }
    ) { padding ->
        lesson?.let {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(16.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Card(
                    modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(text = "شناسه درس: ${it.lessonId}", style = MaterialTheme.typography.labelLarge)
                        Text(text = "زمان پیشنهادی مطالعه: ${it.learningTimeMinutes} دقیقه", style = MaterialTheme.typography.bodyMedium)
                        Text(text = "زمان تمرین: ${it.practiceTimeMinutes} دقیقه", style = MaterialTheme.typography.bodyMedium)
                    }
                }

                Text(text = "معیار تسلط و خروجی مهارتی:", style = MaterialTheme.typography.titleMedium)
                Text(text = it.masteryCriteria, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(vertical = 6.dp))
                Spacer(modifier = Modifier.height(12.dp))

                if (it.practicalExamples.isNotEmpty()) {
                    Text(text = "سناریوهای کاربردی واقعی:", style = MaterialTheme.typography.titleMedium)
                    it.practicalExamples.forEach { example ->
                        Text(text = "• $example", style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(vertical = 4.dp))
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                }

                Button(
                    onClick = { viewModel.markLessonStatus(lessonId, !isRead) },
                    modifier = Modifier.fillMaxWidth().height(50.dp)
                ) {
                    Text(if (isRead) "علامت‌گذاری به عنوان خوانده‌نشده" else "تکمیل درس و ثبت تسلط")
                }
            }
        }
    }
}
