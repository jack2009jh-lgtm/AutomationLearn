package com.aiautomation.engineer.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.aiautomation.engineer.data.UserPreferences
import com.aiautomation.engineer.data.model.CourseData
import com.aiautomation.engineer.data.model.LessonData
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.serialization.json.Json

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val userPrefs = UserPreferences(application)
    private val jsonParser = Json { ignoreUnknownKeys = true }

    private val _courseData = MutableStateFlow<CourseData?>(null)
    val courseData: StateFlow<CourseData?> = _courseData.asStateFlow()

    val readLessons: StateFlow<Set<String>> = userPrefs.readLessonsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptySet())

    init {
        loadCurriculumFromAssets()
    }

    private fun loadCurriculumFromAssets() {
        viewModelScope.launch {
            try {
                val jsonString = getApplication<Application>().assets
                    .open("curriculum.json")
                    .bufferedReader()
                    .use { it.readText() }

                _courseData.value = jsonParser.decodeFromString<CourseData>(jsonString)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun markLessonStatus(lessonId: String, isRead: Boolean) {
        viewModelScope.launch {
            userPrefs.toggleLessonRead(lessonId, isRead)
        }
    }

    fun getLessonById(lessonId: String): LessonData? {
        return _courseData.value?.modules
            ?.flatMap { it.lessons }
            ?.find { it.lessonId == lessonId }
    }
}
